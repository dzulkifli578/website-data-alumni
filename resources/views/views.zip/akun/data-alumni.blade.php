<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Alumni - SMK Swadhipa 2 Natar</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Daisy UI -->
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>

<body class="bg-base-100">
    <div class="flex flex-col min-h-screen">
        <!-- Navbar -->
        @include('akun.navbar')

        <!-- Sidebar -->
        @include('akun.sidebar')

        <!-- Main Content -->
        <div class="flex-1 p-4">
            <!-- Content Header -->
            @include('akun.header')

            <!-- Main Content -->
            <section>
                <div class="bg-base-300 p-4 shadow-md rounded">
                    <!-- Filter dan Search -->
                    <div class="flex flex-col md:flex-row md:flex-wrap gap-4 mb-4">
                        <!-- Filter Nama -->
                        <div class="flex-1">
                            <label for="searchName" class="block text-sm font-medium text-gray-800">Nama:</label>
                            <input type="text" id="searchName"
                                class="form-input mt-1 block w-full shadow-sm p-2 bg-base-100 border border-base-content rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                placeholder="Cari Nama Alumni...">
                        </div>
                        <!-- Filter Jurusan -->
                        <div class="flex-1">
                            <label for="filterMajor" class="block text-sm font-medium text-gray-800">Jurusan:</label>
                            <select id="filterMajor"
                                class="form-select mt-1 block w-full shadow-sm p-2 bg-base-100 border border-base-content rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Semua Jurusan</option>
                                @foreach ($jurusan as $item)
                                    <option value="{{ $item->nama }}">{{ $item->nama }}</option>
                                @endforeach
                            </select>
                        </div>
                        <!-- Filter Tahun Lulus -->
                        <div class="flex-1">
                            <label for="filterYear" class="block text-sm font-medium text-gray-800">Tahun Lulus:</label>
                            <select id="filterYear"
                                class="form-select mt-1 block w-full shadow-sm p-2 bg-base-100 border border-base-content rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                                <option value="">Semua Tahun</option>
                                @foreach ($tahunLulus as $item)
                                    <option value="{{ $item->tahun_lulus }}">{{ $item->tahun_lulus }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>

                    <!-- Pagination Filter -->
                    <div class="mb-4">
                        <form method="GET" action="{{ route('admin-data-alumni') }}">
                            <label for="per_page" class="block text-sm font-medium text-gray-800">Data per
                                halaman:</label>
                            <select name="per_page" id="per_page"
                                class="form-select mt-1 block w-full shadow-sm p-2 bg-base-100 border border-base-content rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                onchange="this.form.submit()">
                                <option value="10" {{ request('per_page') == 10 ? 'selected' : '' }}>10</option>
                                <option value="25" {{ request('per_page') == 25 ? 'selected' : '' }}>25</option>
                                <option value="50" {{ request('per_page') == 50 ? 'selected' : '' }}>50</option>
                                <option value="100" {{ request('per_page') == 100 ? 'selected' : '' }}>100</option>
                                <option value="200" {{ request('per_page') == 200 ? 'selected' : '' }}>200</option>
                                <option value="all" {{ request('per_page') == 'all' ? 'selected' : '' }}>All
                                </option>
                            </select>
                        </form>
                    </div>
                </div>
            </section>

            <section>
                <!-- Data Alumni Table -->
                <div class="overflow-x-auto">
                    <div class="mb-4 flex justify-between items-center mt-4">
                        <!-- Tombol Tambah Alumni -->
                        <a href="{{ route('tambah-data-alumni') }}" class="btn btn-success">
                            <i class="fas fa-plus mr-2"></i> Tambah Alumni
                        </a>
                        <!-- Form Upload CSV -->
                        <form action="{{ route('import-csv') }}" method="POST" enctype="multipart/form-data"
                            class="flex items-center space-x-2">
                            @csrf
                            <input type="file" class="file-input w-full" id="csv_file" name="csv_file"
                                accept=".csv" required>
                            <button type="submit" class="btn btn-info">Upload</button>
                        </form>
                    </div>
                    <table class="table bg-base-100 rounded-lg">
                        <thead class="bg-base-300 text-start text-lg">
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Jenis Kelamin</th>
                                <th>Tahun Lulus</th>
                                <th>Jurusan</th>
                                <th>Detail</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $index => $item)
                                <tr class="border-y border-base-content">
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $item->nama_lengkap }}</td>
                                    <td>{{ $item->jenis_kelamin }}</td>
                                    <td>{{ $item->tahun_lulus }}</td>
                                    <td>{{ $item->jurusan }}</td>
                                    <td>
                                        <a href="{{ route('detail-data-alumni', ['id' => $item->id]) }}"
                                            class="btn btn-info btn-sm">
                                            <span class="fas fa-eye mr-2"></span> Lihat
                                        </a>
                                    </td>
                                    <td>
                                        <form action="{{ route('hapus-data-alumni', ['id' => $item->id]) }}"
                                            method="POST"
                                            onsubmit="return confirm('Apakah kamu yakin menghapus item ini?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-error btn-sm">
                                                <span class="fas fa-trash mr-2"></span> Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    <!-- Link Paginasi -->
                    @if ($paginate)
                        <div class="mt-4 flex justify-center">
                            {{ $data->links('pagination::tailwind') }}
                        </div>
                    @endif
                </div>
            </section>
        </div>
    </div>

    <!-- Footer -->
    @include('akun.footer')

    <!-- Custom JS for Search and Filter Functionality -->
    <script>
        document.getElementById('searchName').addEventListener('keyup', function() {
            const query = this.value.toLowerCase();
            const rows = document.querySelectorAll('#alumniTableBody tr');
            rows.forEach(row => {
                const nameCell = row.querySelector('td:nth-child(2)');
                const name = nameCell.textContent.toLowerCase();
                row.style.display = name.includes(query) ? '' : 'none';
            });
        });

        document.getElementById('filterMajor').addEventListener('change', function() {
            const major = this.value.toLowerCase();
            const rows = document.querySelectorAll('#alumniTableBody tr');
            rows.forEach(row => {
                const majorCell = row.querySelector('td:nth-child(4)');
                const rowMajor = majorCell.textContent.toLowerCase();
                row.style.display = major === '' || rowMajor.includes(major) ? '' : 'none';
            });
        });

        document.getElementById('filterYear').addEventListener('change', function() {
            const year = this.value;
            const rows = document.querySelectorAll('#alumniTableBody tr');
            rows.forEach(row => {
                const yearCell = row.querySelector('td:nth-child(3)');
                const rowYear = yearCell.textContent;
                row.style.display = year === '' || rowYear === year ? '' : 'none';
            });
        });
    </script>
</body>

</html>
