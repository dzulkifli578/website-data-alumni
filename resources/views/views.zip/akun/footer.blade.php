<footer class="bg-gray-800 text-white p-4 text-center">
    &copy; 2024 SMK Swadhipa 2 Natar. All rights reserved.
</footer>
