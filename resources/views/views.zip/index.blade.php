<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - SMK Swadhipa 2 Natar</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Daisy UI -->
    <link href="https://cdn.jsdelivr.net/npm/daisyui@4.12.10/dist/full.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
</head>

<body class="bg-base-100">
    <!-- Navbar -->
    @include('navbar')

    <!-- Hero -->
    <section class="relative bg-cover bg-center text-white py-52"
        style="background-image: url('{{ asset('img/sekolah.jpg') }}');">
        <div class="absolute inset-0 bg-black/50 z-10"></div>
        <div class="relative z-20 container mx-auto text-center px-4">
            <h1 class="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">Selamat Datang di Web Data Alumni</h1>
            <p class="text-base md:text-lg lg:text-xl mb-6">Hubungkan masa lalu dengan masa depan. Jelajahi dan tetap
                terhubung dengan sesama alumni.</p>
            <a href="{{ route('data-alumni') }}"
                class="btn btn-outline btn-light text-white border-white hover:bg-white hover:text-black py-2 px-4 md:py-3 md:px-6 rounded-full">Lihat
                Semua Alumni</a>
        </div>
    </section>

    <!-- Jurusan -->
    <section class="my-10">
        <div class="container mx-auto px-4">
            <h2 class="text-2xl font-bold mb-4 text-center">Jurusan</h2>
            <div class="flex flex-wrap gap-4 justify-center">
                <div onclick="window.location.href='{{ route('rpl') }}'"
                    class="flex flex-col justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/rpl.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black font-bold text-center">Rekayasa Perangkat Lunak</p>
                </div>
                <div onclick="window.location.href='{{ route('tkj') }}'"
                    class="flex flex-col justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/tkj.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black text-center">Teknik Komputer dan Jaringan</p>
                </div>
                <div onclick="window.location.href='{{ route('titl') }}'"
                    class="flex flex-col justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/titl.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black text-center">Teknik Instalasi Tenaga Listrik</p>
                </div>
                <div onclick="window.location.href='{{ route('tkr') }}'"
                    class="flex flex-col justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/tkr.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black text-center">Teknik Kendaraan Ringan</p>
                </div>
                <div onclick="window.location.href='{{ route('tbsm') }}'"
                    class="flex flex-col justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/tbsm.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black text-center">Teknik Bisnis dan Sepeda Motor</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistik -->
    <section class="my-10">
        <div class="container mx-auto px-4">
            <h2 class="text-2xl font-bold mb-4 text-center">Jurusan</h2>
            <div class="flex flex-wrap gap-4 justify-center">
                <div onclick="window.location.href='{{ route('rpl') }}'"
                    class="flex flex-col items-center justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/rpl.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black font-bold text-center">Rekayasa Perangkat Lunak</p>
                </div>
                <div onclick="window.location.href='{{ route('tkj') }}'"
                    class="flex flex-col items-center justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/tkj.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black font-bold text-center">Teknik Komputer dan Jaringan</p>
                </div>
                <div onclick="window.location.href='{{ route('titl') }}'"
                    class="flex flex-col items-center justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/titl.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black font-bold text-center">Teknik Instalasi Tenaga Listrik</p>
                </div>
                <div onclick="window.location.href='{{ route('tkr') }}'"
                    class="flex flex-col items-center justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/tkr.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black font-bold text-center">Teknik Kendaraan Ringan</p>
                </div>
                <div onclick="window.location.href='{{ route('tbsm') }}'"
                    class="flex flex-col items-center justify-center w-full sm:w-1/2 md:w-1/3 lg:w-1/5 bg-base-300 p-4 rounded-2xl group hover:bg-warning transition-colors duration-300 cursor-pointer">
                    <img src="{{ asset('img/tbsm.svg') }}" alt="Icon" class="my-4 h-32 mx-auto">
                    <p class="group-hover:text-black font-bold text-center">Teknik Bisnis dan Sepeda Motor</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    @include('footer')
</body>

</html>
